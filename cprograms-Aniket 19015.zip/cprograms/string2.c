#include <stdio.h>
#include<strings.h>
main()
{
    char my_name[50];
    char chr;
   
   
    printf("Enter your name ");
    //scanf("%s",my_name);
    for(int i=0;i<15;i++)
        my_name[i]=getchar();
        //printf("%c",my_name[i]);
    printf("\nWelcome Mr.%s you are a %c\n",my_name,chr);

        printf("\n");
}