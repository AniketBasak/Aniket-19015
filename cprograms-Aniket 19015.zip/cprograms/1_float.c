#include <stdio.h>
main()
{
float f1=3.14523654128756425; 
float f2=12547856923512.2511254785412369;   
printf("%.8f\n",f1);
printf("%3.5f\n",f1);
printf("%3.5f\n",f2);
printf("%d\n",sizeof(f1));
printf("%d\n",sizeof(f2));
}