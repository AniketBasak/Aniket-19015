#include<stdio.h>

int main(void)

{

struct complex{
int r;
int i;
char  *p;
};

struct complex p1;

printf("size of p1 %lu\t p1.p %lu\n", sizeof(p1),sizeof(p1.p));
printf("size of p1 %lu\n", sizeof(p1));
printf("address of p1 \t %p\n",&p1);
printf("address of p1.r \t %p\n",&(p1.r));
printf("address of p1.i \t %p\n",&(p1.i));
//printf("address of p1.a \t %p\n",&(p1.a));
//printf("value at p1.a \t %d\n",(p1.a));
struct complex p2;
printf("address of p2 \t %p\n",&p2);




}
