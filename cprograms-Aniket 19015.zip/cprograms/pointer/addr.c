#include <stdio.h>

int main(void)
{
    int x = 100;
    char c='A';
    printf("\n d: %d\t sizeof_int :%d", &x, sizeof(x));
    printf("\n ld:%ld\t sizeof_long_int :%d", &x, sizeof(long int));
    printf("\n p:%p", &x);  // %p is used for printing address.
    printf("\n after dereference:%d", *&x);
    printf("\n address of char c :%p", &c);
    printf("\n");
}
