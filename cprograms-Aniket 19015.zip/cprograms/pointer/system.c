#include<stdio.h>
#include<stdlib.h>

void main(void)
{

    system("rmdir test");
}