#include <stdio.h>

int main(void)
{

    int x[5] = {1, 2, 3, 4, 5};

    printf("\n%p", x);
    printf("\n%p", &x[0]);
    printf("\n%p", &x[1]);
    printf("\n%p", &x[2]);
    printf("\n%p", &x[3]);
    printf("\n");
}
