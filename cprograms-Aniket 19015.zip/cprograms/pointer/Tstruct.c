#include<stdio.h>

int main(void)

{

struct complex{
int r;
int i;
char *str;
};
struct complex p1,p2;

printf("address of p1 %p\n",&p1);
printf("address of p1.r %p\n",&(p1.r));
printf("address of p1.i %p\n",&(p1.i));
printf("size  of p1 %lu\n",sizeof(p1));

}
