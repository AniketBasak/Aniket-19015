#include <stdio.h>

void main(void)
{

int arr[3]={1,2,3};

for(int i=0; i<5;i++)
	printf("\n %d - %d", i,arr[i]);

printf("\n*****************\n");

}
