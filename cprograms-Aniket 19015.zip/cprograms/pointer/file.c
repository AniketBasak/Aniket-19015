#include <stdio.h>

int main()
{
FILE *fp,*fp2,*fp3;
char chr;
fp=fopen("test.c","r");
//fp2=fopen("tt","w");
fp3=fopen("tt","a");

while((chr=getc(fp))!=EOF)
{
    printf("%c",chr);
    putc(chr+45,fp3);
}
printf("\n");
printf("%d",chr);
printf("\n");
fclose(fp);
//fclose(fp3);
}