#include <stdio.h>

typedef unsigned ui;
int main(void)
{

    typedef unsigned ui;

    ui x = 100;
    printf("\nx=%d\n", x);
}
