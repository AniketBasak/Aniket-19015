#include <stdio.h>

int main(void)
{
    char * st = "IISERBPR";
    char str[10] = "IISERBPR";
    char * str_array[]={"Gopi","Krishna","Rama","Shyama"};
    
    for(int i=0;i<4;i++)
        printf("%s\n",str_array[i]);    
    
    printf("%p\n", str);
    printf("%p\n", &str[0]); // address of zeroth location of str array

// what we can conclude is the name of any array is nothing but the address of its zeroth location


    //printf("\n%c", *str);
   // str[3] = '7';
   // printf("%s\n", str);
   // printf("before-  *(st+3): %c\n", *(st + 3));
    //*(st + 3) = '7';
   // printf("after- st: %s\n", st);
    //st = str;
    //*(st + 3) = '7';
    //printf("%s\n", st);
    //printf("\n");
}
