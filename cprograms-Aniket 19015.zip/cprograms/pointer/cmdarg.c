#include<stdio.h>

int main(int nc, char *cc[])
{
if(nc<2)
{
    printf("No oprands except the file name it self");
}
else
{
    for(int i=0;i<nc;i++)
        printf("%d\t%s\n",i,cc[i]);
}
// for (int i=0;i<10;i++)
// 	printf("%s\n", argv[i]);
}
