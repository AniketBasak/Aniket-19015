#include <stdio.h>

main()
{

    int x = 100;
    int *px;
    px = &x;
    float *fx;
    printf("\n%d is stored in %d ", x, &x);
    printf("\n%d is stored in %lu ", x, &x);
    printf("\n%d is stored in %p ", x, &x);

    printf("\n%d also %d ", x, *px);
    printf("\nsizeof integer pointer varaible %d", sizeof(px));
    printf("\nsizeof float pointer varaible %d", sizeof(fx));
}