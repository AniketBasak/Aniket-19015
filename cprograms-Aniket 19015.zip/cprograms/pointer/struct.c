#include<stdio.h>

int main(void)

{

struct complex{
int r;
int i;
};

struct complex p1,p2;

p1.r=10;
p1.i=5;

p2.r=3;
p2.i=4;
printf("p2.r %d",p2.r);

}
