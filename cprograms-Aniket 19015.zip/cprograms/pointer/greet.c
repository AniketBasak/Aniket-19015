#include<stdio.h>

int main(int nc, char *cc[])
{
if(nc<2)
{
    printf("No oprands except the file name it self");
}
else
{
    printf("\n Hello Mr. %s\n",cc[1]);
}
// for (int i=0;i<10;i++)
// 	printf("%s\n", argv[i]);
}
