#include<stdio.h>

int main(void)
{

char *arr[]={"python","C++","pascal", "fortran"};

printf("%s\n",arr[1]);


}

