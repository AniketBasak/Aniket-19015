#include <stdio.h>

main()
{
    char abc[]="Hello";
    printf("%s\n",abc);
    for (int i=0;i<15;i++)
        printf("%d\t%d\n",i, abc[i]);
}