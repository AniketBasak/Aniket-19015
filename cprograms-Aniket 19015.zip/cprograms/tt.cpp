#include<iostream>
void main(void)

{
int yu=0;
yu=++yu;
cout<<"pre increment :"<<yu<<endl;
yu=--yu;
cout<<"original value :"<<yu<<endl;
yu=yu++;
cout<<"post increment :"<<yu< <endl;
cout<<"post increment after usage result:"<<yu<<endl;//why is not changing
}
