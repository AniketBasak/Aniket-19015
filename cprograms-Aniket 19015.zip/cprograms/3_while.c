#include<stdio.h>

main()
{
    int x=5;
    while(x>0)
        {
            printf("%d\n",x);
            x=x-2;
        }
    printf("I am out of loop");     
}