#include<stdio.h>
/*

*/
main()
{
    int a=100;
    int b=15;
    printf("a+b = %d \n", a+b);
    printf("a-b = %d \n", a-b);
    printf("a*b = %d \n", a*b);
    printf("a/b = %f \n", (float)a/b);
    printf("%d\n",a%b); 
}