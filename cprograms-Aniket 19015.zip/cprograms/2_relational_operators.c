#include<stdio.h>

main()
{
    int a=100;
    int b=15;
    printf("%d\n",a>b); // greater than
    printf("%d\n",a<b); // less than
    printf("%d\n",a!=b); // not equl to
    printf("%d\n",a==b); // equal to 
    printf("%d\n",a>=b); // greater than or equal to
    printf("%d\n",a<=b); // less than or equal to
}