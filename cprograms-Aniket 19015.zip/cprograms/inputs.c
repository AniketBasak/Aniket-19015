#include <stdio.h>

int main()
{
    int x;
    float f1;
    char my_name[50];
    int int_ar[4]={1,2,3,4};
    char chr;

    //printf("Enter a char");
    // scanf("%c",&chr);
    // printf("\nChar that you entered is %c\n",chr);
    //chr=getchar();
    printf("Enter Your name");
    printf("\nChar that you entered is %c\n",chr);
    for(int i=0;i<10;i++)
        my_name[i]=getchar();
    printf("\nString that you entered is %s\n",my_name);



    // printf("Enter an integer value");
    // scanf("%d",&x);
    // printf("\n Enter a real number");
    // scanf("%f",&f1);
    // printf("\n what is your name?");
    // scanf("%s",my_name);
    //printf("Double the value of integer is %d\n",2*x);
    //printf("Double the value of float is %f\n",2*f1);
    //printf("Your name is %s\n",my_name);
    // for(int i=0;i<15;i++)
    //     printf("%d \t%d\n",i,my_name[i]);
    // printf("\n");
    // printf("Address of array %p\n",my_name);
    // printf("Address of array %p\n",&my_name[0]);

    // printf("Address of integer array %p\n",int_ar);
    // for(int i=0;i<4;i++)
    //     printf("%d \t Address of array %p\n",i,&int_ar[i]);
}