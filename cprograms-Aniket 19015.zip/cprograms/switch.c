#include<stdio.h>
main()
{

int a=9;

switch(a)
{
case 9:
    printf("Hello 1");
   // break;
case 3: 
    printf("Hello 2");
   // break;
default:
    printf("Neither 1 nor 2");
    break;
}
}
