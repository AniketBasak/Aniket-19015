#include<stdio.h>
void main(void)

{
int yu=0;
yu=++yu;
printf("pre increment :%d\n",yu);
yu=--yu;
printf("pre increment :%d\n",yu);
yu=yu++;
printf("pre increment :%d\n",yu);
printf("pre increment :%d\n",yu);
printf("pre increment :%d\n",yu);
printf("pre increment :%d\n",yu);
}
